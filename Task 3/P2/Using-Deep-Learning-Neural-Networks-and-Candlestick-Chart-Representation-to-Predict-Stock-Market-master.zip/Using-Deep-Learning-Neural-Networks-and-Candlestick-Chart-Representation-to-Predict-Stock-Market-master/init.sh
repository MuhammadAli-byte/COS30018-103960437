python3.6 -m venv .venv/default
source .venv/default/bin/activate
pip3 install -U -r requirements.txt
